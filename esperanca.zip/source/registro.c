#include <string.h>
#include "registro.h"
#include "fornecidas.h"
#include "sep.h"
#include "FUNCs.h"

//lê o arquivo, atribui ao registro
int lerRegistro(Registro *reg, FILE *arquivoBin)
{
    if(!fread(&reg->removido, sizeof(char), 1, arquivoBin)){
        return 0;
    }
    fread(&reg->encadeamentoPilha, sizeof(int), 1, arquivoBin);
    fread(&reg->idPoPs, sizeof(int), 1, arquivoBin);
    fread(&reg->idPoPsConectado, sizeof(int), 1, arquivoBin);
    fread(&reg->velocidade, sizeof(int), 1, arquivoBin);
    fread(&reg->unidadeMedida, sizeof(char), 1, arquivoBin);
    return 1;
}

//lê o registro, atribui ao arquivo
void escreverRegistro(Registro *reg, FILE *arquivoBin)
{
    fwrite(&reg->removido, sizeof(char), 1, arquivoBin);
    fwrite(&reg->encadeamentoPilha, sizeof(int), 1, arquivoBin);
    fwrite(&reg->idPoPs, sizeof(int), 1, arquivoBin);
    fwrite(&reg->idPoPsConectado, sizeof(int), 1, arquivoBin);
    fwrite(&reg->velocidade, sizeof(int), 1, arquivoBin);
    fwrite(&reg->unidadeMedida, sizeof(char), 1, arquivoBin);
}

//lê o arquivo, atribui ao cabeçalho
void lerCabecalho(Cabecalho *cab, FILE *arquivoBin)
{
    fread(&cab->status, sizeof(char), 1, arquivoBin);
    fread(&cab->topoPilha, sizeof(int), 1, arquivoBin);
    fread(&cab->proxRRN, sizeof(int), 1, arquivoBin);
    fread(&cab->nroRegRem, sizeof(int), 1, arquivoBin);
    fread(&cab->nroPares, sizeof(int), 1, arquivoBin);
}

//lê o cabeçalho, atribui ao arquivo
void escreverCabecalho(Cabecalho *cab, FILE *arquivoBin)
{
    fwrite(&cab->status, sizeof(char), 1, arquivoBin);
    fwrite(&cab->topoPilha, sizeof(int), 1, arquivoBin);
    fwrite(&cab->proxRRN, sizeof(int), 1, arquivoBin);
    fwrite(&cab->nroRegRem, sizeof(int), 1, arquivoBin);
    fwrite(&cab->nroPares, sizeof(int), 1, arquivoBin);
}

void voltaUmRegistro(FILE *arquivoBin){
    fseek(arquivoBin, (-TAM_REG), SEEK_CUR);
}

void acaoBusca(int opcao, Registro *reg, Cabecalho *cab, FILE* arqBin){
    switch (opcao)
        {
            case 3: //imprimir resultados da busca
                imprimirRegistro(*reg);
                break;
            
            case 5:
                excluirRegistro(reg, cab, arqBin);
                break;

            case 7:
                atualizarRegistro(reg, arqBin);
                break;
            default:
                break;
        }
}

void buscaRegistro(FILE *arquivoBin, int opcao){

    int n; //numero de buscas que ocorrera
    scanf("%d", &n);
    for(int i=0; i<n; i++){
        fseek(arquivoBin, 0, SEEK_SET);
        int m; //quantidade de pares para filtrar
        scanf("%d", &m);

        Cabecalho cab;
        lerCabecalho(&cab, arquivoBin);
        
        int p=1; //quantidade de pares de valores novos
        
        
        // Registro novoReg; ////////////////// <- update
        BuscaPar par[m];
        Registro reg;
        reg.RRN = -1; //começa -1 então o 1º é 0
        
        for(int j=0; j<m; j++){
            scanf("%s", par[j].NomeCampo);
            if(strcmp(par[j].NomeCampo, "unidadeMedida")==0){
                ScanQuoteString(par[j].ValorCampo);
            }else{
                scanf("%s", par[j].ValorCampo);
            }
        }
        
////////////////////////////update//////////////////////////////
        if(opcao == 7){
            //printf("\nLeitura de p:\n");
            scanf("%d", &p);
        }
        BuscaPar novoPar[p];
            
        if(opcao == 7){
            for(int j=0; j<p; j++){
                //printf("\nLeitura do nome do campo a ser atualizado: ");
                scanf("%s", novoPar[j].NomeCampo);
                //printf("\nLeitura do valor do campo a ser atualizado: ");
                if(strcmp(novoPar[j].NomeCampo, "unidadeMedida")==0){
                    ScanQuoteString(novoPar[j].ValorCampo);
                    if(!(novoPar[j].ValorCampo)[0]){
                        strcpy(novoPar[j].ValorCampo, "NULO");
                    }
                }else{
                    scanf("%s", novoPar[j].ValorCampo);
                }
            }
        }
////////////////////////////////////////////////////////////////
        while(lerRegistro(&reg, arquivoBin))
        {
            //imprimirRegistro(reg);
            reg.RRN++;
            //printf("\nRRN = %d", reg.RRN);

            if(reg.removido == '1')
            {
                continue;
            }

            int controle = 0; //se 0 não bate, se 1 bate
            for(int j=0; j<m; j++){ //verifica se bate com cada par

                if((strcmp(par[j].NomeCampo, "idPoPs")==0)){
                    if((atoi(par[j].ValorCampo) == reg.idPoPs)){
                        controle = 1;
                    }else{
                        controle = 0;
                        break;
                    }
                }

                if((strcmp(par[j].NomeCampo, "idPoPsConectado")==0)){
                    if((atoi(par[j].ValorCampo) == reg.idPoPsConectado)){
                        controle = 1;
                    }else{
                        controle = 0;
                        break;
                    }
                }

                if((strcmp(par[j].NomeCampo, "velocidade")==0)){
                    if((strcmp(par[j].ValorCampo, "NULO")==0) && (reg.velocidade==-1)){
                        controle = 1;
                    }else if((atoi(par[j].ValorCampo) == reg.velocidade) ){
                        controle = 1;
                    }else{
                        controle = 0;
                        break;
                    }
                }

                if(strcmp(par[j].NomeCampo, "unidadeMedida")==0){
                    if((strcmp(par[j].ValorCampo, "NULO")==0) && (reg.unidadeMedida == '$')){
                        controle = 1;
                    }
                    else{
                        if((par[j].ValorCampo)[0] == reg.unidadeMedida){
                            controle = 1;
                        }else{
                            controle = 0; //todos os filtros devem bater
                            break;
                        }
                    }
                    
                }

            }
            //printf("\nCONTROLE = %d\n", controle);
            if(controle){
//////////////////////////////////////////update/////////////////////////////////////////////
                if(opcao == 7){
                    for(int k=0; k<p; k++){
                        //printf("\nloop %d\n", k);
                        //printf("\nCampo a ser atualizado: %s Para o valor %s", novoPar[k].NomeCampo, novoPar[k].ValorCampo);
                        if(strcmp(novoPar[k].NomeCampo, "idPoPs")==0){
                            reg.idPoPs = atoi(novoPar[k].ValorCampo);
                        }
                        if(strcmp(novoPar[k].NomeCampo, "idPoPsConectado")==0){
                            reg.idPoPsConectado = atoi(novoPar[k].ValorCampo);
                        }
                        if(strcmp(novoPar[k].NomeCampo, "velocidade")==0){
                            if(strcmp(novoPar[k].ValorCampo, "NULO")==0){
                                reg.velocidade = -1;
                            }
                            else{
                                reg.velocidade = atoi(novoPar[k].ValorCampo);
                            }
                        }
                        if(strcmp(novoPar[k].NomeCampo, "unidadeMedida")==0){
                            if(strcmp(novoPar[k].ValorCampo, "NULO")==0){
                                //printf("\n------------ELE TA TENTANDO"); //nao chegou
                                reg.unidadeMedida = '$';
                            }
                            else{
                                reg.unidadeMedida = (novoPar[k].ValorCampo)[0];
                            }
                        }
                        
                    }
                }
//////////////////////////////////////////////////////////////////////////////////////////////
                //printf("\nAcao na busca!!");
                acaoBusca(opcao, &reg, &cab, arquivoBin);
            }
        }

        if(opcao == 3) //runcodes :C
            printf("\n");
    }
}

void imprimirRegistro(Registro reg){
    //if(reg.removido == '0'){ //// acaoBusca já pula os removidos

    printf("%d %d ", reg.idPoPs, reg.idPoPsConectado); //Não podem ser nulos
    if(reg.velocidade == -1){
        printf("NULO ");
    }else{
        printf("%d ", reg.velocidade);
    }
    if(reg.unidadeMedida == '$'){
        printf("NULO\n");
    }else{
        printf("\"%c\"\n", reg.unidadeMedida);
        }

    //}
}

void excluirRegistro(Registro *reg, Cabecalho *cab, FILE* arqBin)
{
        //printf("Registro que vai ser removido: ");
        //imprimirRegistro(*reg);
    //altero valores do cabecalho
    cab->status = '0';
    int preTopoPilha = cab->topoPilha;
    cab->topoPilha = reg->RRN;
    cab->nroRegRem += 1;
    cab->nroPares -= 1;

    //volta pro começo do arquivo
    fseek(arqBin, 0, SEEK_SET);

    escreverCabecalho(cab, arqBin);

    // [removido] [encadeamentoPilha] [idPoP](int) [idPoPsConectado](int) [velocidade](int) [unidadeMedida](char)
    
    //atributos de controle com valor
    reg->removido = '1';
    reg->encadeamentoPilha = preTopoPilha; //eu podia colocar um if mas fica -1 anyway se for o 1º
    
    //resto com lixo
    // memset(&reg->idPoPs, '$', sizeof(int));
    // memset(&reg->idPoPsConectado, '$', sizeof(int));
    // memset(&reg->velocidade, '$', sizeof(int));
    // reg->unidadeMedida = '$';
    
    //vou até o registro q está sendo excluido
    fseek(arqBin, (reg->RRN * TAM_REG), SEEK_CUR);

    escreverRegistro(reg, arqBin); 

    fseek(arqBin, 0, SEEK_SET);
    cab->status = '1';

    // fwrite(cab->status, sizeof(char), 1, arqBin);
    // fseek(arqBin, (((reg->RRN + 1) * TAM_REG)-1), SEEK_CUR);

    //da dó de reescrever o cabecalho inteiro só pelo status, daria pra usar o código comentado acima como alternativa
    escreverCabecalho(cab, arqBin); 
    fseek(arqBin, ((reg->RRN + 1) * TAM_REG), SEEK_CUR);
    
    //termina onde estava no acaoBusca
    
    return;
}

void atualizarRegistro(Registro *reg, FILE *arqBin){
    voltaUmRegistro(arqBin);
    //printf("\nRegistro atualizado: \n");
    //imprimirRegistro(*reg);
    escreverRegistro(reg, arqBin);
}


